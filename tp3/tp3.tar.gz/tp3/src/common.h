#ifndef COMMON_H
#define COMMON_H

/* Signale une erreure fatale.  Arguments comme `printf`.  */
void error (const char* fmt, ...);

#endif

